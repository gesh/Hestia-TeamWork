var animateSpalshScreen;

animateSpalshScreen = function () {
    $('#main-screen').append("<img id='theImg' src='../styles/images/appbuilder.png'/>").show();

};